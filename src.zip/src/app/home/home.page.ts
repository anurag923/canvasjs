import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
declare const CanvasJS: any;
import * as $ from 'jquery';
import { webSocket } from "rxjs/webSocket";
const subject = webSocket("wss://socket.polygon.io/crypto");
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit{
  livedata:any;
  datapoints = []
  
  constructor(private http:HttpClient,private datePipe: DatePipe) {}
  ngOnInit(){
	
    subject.next({action:"auth",params:"6sEFcNe2upitHW5lt9dp7EfkIuxoR58k"});
    subject.subscribe(
      (msg) => {console.log('message received: ' + msg);
      this.livedata = msg;
	  for(var i=0;i<this.livedata.length;i++){
		  if("p" in this.livedata[i]){
			var formattedTime = this.datePipe.transform(this.livedata[0].t,'HH:mm:ss');
			this.datapoints.push({y:this.livedata[0].p,label:formattedTime});
			console.log('datapoints',this.datapoints);
			
		  }
	  }

		let chart = new CanvasJS.Chart("chartContainer1",{
			exportEnabled: true,
			title:{
				text:"Live Chart with Data-Points from External JSON"
			},
			data: [{
				type: "line",
				dataPoints : this.datapoints,
			}]
		});
		console.log('chart',chart);
		chart.render();
    }, // Called whenever there is a message from the server.
      (err) => {console.log(err)}, // Called if at any point WebSocket API signals some kind of error.
      () => console.log('complete') // Called when connection is closed (for whatever reason).
    );
    subject.next({action:"subscribe",params:"XT.BTC-USD"});
	
}

}
